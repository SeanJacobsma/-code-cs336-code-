Project:Tracking Every Assignment: Progress Over Time</br>
Codename: .sendstatus(418)</br>
Dem Bois: Sean Jacobsma, Ben Fynan, Jorden Hordyk</br>

Our idea for our web app is a homework planner. Most todo lists have a system set up to allow
the addition of an item to the list, and a function to remove the item when it is done.
However, there is no way to mark when work will be done or when the assignment is planned to be finished. This is a feature that many students could benefit from, as it allows them to fully plan out their week. This will help to make all assignments are turned in on time, and if an assignment cannot be completed on time, they can let their professor know sooner than the night before. The assignments will be displayed on a weekly chart.
