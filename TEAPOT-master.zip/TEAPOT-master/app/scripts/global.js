const API_URL = 'api/tasks';
const POLL_INTERVAL = 2000;

module.exports = {API_URL, POLL_INTERVAL};
